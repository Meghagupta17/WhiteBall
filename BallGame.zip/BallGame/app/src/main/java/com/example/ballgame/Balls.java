package com.example.ballgame;

public class Balls {

    int x;
    int y;
    int radius;
}
