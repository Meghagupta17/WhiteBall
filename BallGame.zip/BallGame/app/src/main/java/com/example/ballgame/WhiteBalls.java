package com.example.ballgame;

public class WhiteBalls extends Balls {
    int speed;

    int score;
}
